package gui;

import DataBase.CartDAO;
import DataBase.CustomerDAO;
import DataBase.PaymentDAO;
import DataBase.ProductDAO;
import static gui.Login.CusId;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Cart;
import model.Customer;
import model.Payment;
import model.Product;

public class CustomerPanel extends javax.swing.JFrame {
    
    private ProductDAO productDAO;
    private DefaultTableModel productTableModel; // Product table model
    private DefaultTableModel cartTableModel;
    
    private CustomerDAO customerDAO; // Add this
    private CartDAO cartDAO; // Add this
    private PaymentDAO paymentDAO; // Add this

    public CustomerPanel() {
        initComponents();
        customerIDTxt.setText(CusId);
        productDAO = new ProductDAO(); // Initialize the DAO
        productTableModel = (DefaultTableModel) pruductTable.getModel(); // Assign the product table model
        cartTableModel = (DefaultTableModel) cartTable.getModel(); // Assign the cart table model

        // Initializing your table models
        cartTableModel = (DefaultTableModel) cartTable.getModel();
        customerDAO = new CustomerDAO();
        cartDAO = new CartDAO();
        paymentDAO = new PaymentDAO();
        
        fillProductTable(); // Fill the product table with products

    }
    
    private void checkout() {
        if (cartTableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Your cart is empty.");
            return;
        }
        
        List<Customer> customers = customerDAO.getAllCustomers();
//        customers.setCustomerId(1);
        Customer selectedCustomer = selectCustomer(customers);
        
        if (selectedCustomer == null) {
            JOptionPane.showMessageDialog(this, "Checkout canceled.");
            return;
        }
        
        int orderId = generateOrderId(); // A method to generate unique order IDs
        Cart cart = new Cart(orderId, selectedCustomer.getCustomerId(), 2, selectedCustomer, null);
        
        cartDAO.createCart(cart);
        
        Payment payment = new Payment(0, calculateTotalCost(), orderId, cart); // Calculate the total cost of the cart
        paymentDAO.createPayment(payment);
        
        updateTotalCost();

        // Display the receipt or confirmation
        displayReceipt(selectedCustomer, cart, payment);
        
        JOptionPane.showMessageDialog(this, "Thank you for your purchase!");

        // Clear the cart table after checkout
        cartTableModel.setRowCount(0);
    }
    
    private Customer selectCustomer(List<Customer> customers) {
        // Logic for selecting a customer. Could be a dialog or list selection.
        // For simplicity, let's assume you return the first customer.
        return customers.isEmpty() ? null : customers.get(0);
    }
    
    private void updateTotalCost() {
        // Logic to update total cost in the UI after checkout or any other changes.
        priceLabel.setText(String.format("Total: $%.2f", calculateTotalCost()));
    }
    
    private double calculateTotalCost() {
        double total = 0.0;
        for (int i = 0; i < cartTableModel.getRowCount(); i++) {
            double price = Double.parseDouble(cartTableModel.getValueAt(i, 1).toString());
            int quantity = Integer.parseInt(cartTableModel.getValueAt(i, 2).toString());
            total += price * quantity;
        }
        return total;
    }
    
    private void displayReceipt(Customer customer, Cart cart, Payment payment) {
        DefaultListModel<String> receiptModel = new DefaultListModel<>();
        receiptModel.addElement("Receipt:");
        receiptModel.addElement("Customer Id: " + CusId);
        receiptModel.addElement("Order ID: " + cart.getOrderId());
        receiptModel.addElement("Total Cost: $" + payment.getPayAmount());

        // Add each product in the cart to the receipt
        for (int i = 0; i < cartTableModel.getRowCount(); i++) {
            String productName = cartTableModel.getValueAt(i, 0).toString();
            double price = Double.parseDouble(cartTableModel.getValueAt(i, 1).toString());
            int quantity = Integer.parseInt(cartTableModel.getValueAt(i, 2).toString());
            
            receiptModel.addElement(String.format("Product: %s | Price: $%.2f | Quantity: %d", productName, price, quantity));
        }

        // Set the billList model to the updated receipt model
        billList.setModel(receiptModel);
    }
    
    private int generateOrderId() {
        // Logic to generate a unique order ID. Could be based on time, counter, or UUID.
        return (int) (Math.random() * 100000); // Example: Generate a random order ID
    }
    
    private void addToCart(String name, Product product, int quantity) {
        
        Object[] row = {
            product.getProductName(),
            product.getPrice(), // Ensure price is in correct format
            product.getStock() // Product stock
        };
        cartTableModel.addRow(row);
    }
    
    private void fillProductTable() {
        // Get the list of products from the database
        List<Product> products = productDAO.getAllProducts();

        // Clear the existing rows in the product table model
        productTableModel.setRowCount(0);

        // Add each product to the table model
        for (Product product : products) {
            Object[] row = {
                product.getProductName(),
                product.getPrice(), // Ensure price is in correct format
                product.getStock() // Product stock
            };
            productTableModel.addRow(row); // Add row to the table model
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel21 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        billList = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        pruductTable = new javax.swing.JTable();
        priceTxt = new javax.swing.JTextField();
        nameTxt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        addButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        removeButton = new javax.swing.JButton();
        checkoutButton = new javax.swing.JButton();
        priceLabel = new javax.swing.JLabel();
        quantityBox = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        cartTable = new javax.swing.JTable();
        customerIDTxt = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        rSLabelImage7 = new rojerusan.RSLabelImage();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();

        jLabel21.setBackground(new java.awt.Color(204, 102, 0));
        jLabel21.setFont(new java.awt.Font("Tahoma", 3, 27)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(102, 0, 0));
        jLabel21.setText("MANAGE EMPLOYEE");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Aplus Bakery - Cart");
        setMinimumSize(new java.awt.Dimension(968, 623));
        setResizable(false);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        billList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        billList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                billListMouseClicked(evt);
            }
        });
        billList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                billListValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(billList);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(460, 330, 450, 130);

        pruductTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Name", "Price", "Quantity"
            }
        ));
        pruductTable.setSelectionBackground(new java.awt.Color(204, 204, 255));
        pruductTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pruductTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(pruductTable);

        jPanel2.add(jScrollPane2);
        jScrollPane2.setBounds(460, 170, 450, 93);

        priceTxt.setEditable(false);
        priceTxt.setColumns(14);
        jPanel2.add(priceTxt);
        priceTxt.setBounds(250, 220, 140, 30);

        nameTxt.setEditable(false);
        nameTxt.setColumns(14);
        jPanel2.add(nameTxt);
        nameTxt.setBounds(250, 180, 140, 30);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Price");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(90, 220, 33, 17);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Customer Id");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(90, 140, 120, 21);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Quantity");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(90, 260, 60, 17);

        addButton.setBackground(new java.awt.Color(102, 0, 0));
        addButton.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        addButton.setForeground(new java.awt.Color(255, 255, 255));
        addButton.setText("ADD");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        jPanel2.add(addButton);
        addButton.setBounds(110, 310, 100, 40);

        clearButton.setBackground(new java.awt.Color(102, 0, 0));
        clearButton.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        clearButton.setForeground(new java.awt.Color(255, 255, 255));
        clearButton.setText("CLEAR");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });
        jPanel2.add(clearButton);
        clearButton.setBounds(230, 310, 110, 40);

        removeButton.setBackground(new java.awt.Color(102, 0, 0));
        removeButton.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        removeButton.setForeground(new java.awt.Color(255, 255, 255));
        removeButton.setText("REMOVE");
        removeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeButtonActionPerformed(evt);
            }
        });
        jPanel2.add(removeButton);
        removeButton.setBounds(630, 470, 130, 40);

        checkoutButton.setBackground(new java.awt.Color(102, 0, 0));
        checkoutButton.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        checkoutButton.setForeground(new java.awt.Color(255, 255, 255));
        checkoutButton.setText("CHECKOUT");
        checkoutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkoutButtonActionPerformed(evt);
            }
        });
        jPanel2.add(checkoutButton);
        checkoutButton.setBounds(770, 470, 130, 40);

        priceLabel.setBackground(new java.awt.Color(102, 0, 0));
        priceLabel.setFont(new java.awt.Font("Century Gothic", 1, 20)); // NOI18N
        priceLabel.setForeground(new java.awt.Color(153, 51, 0));
        priceLabel.setText("Total");
        jPanel2.add(priceLabel);
        priceLabel.setBounds(460, 470, 170, 26);

        quantityBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        jPanel2.add(quantityBox);
        quantityBox.setBounds(250, 260, 140, 30);

        cartTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Price", "Quantity"
            }
        ));
        cartTable.setSelectionBackground(new java.awt.Color(204, 204, 255));
        cartTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cartTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(cartTable);

        jPanel2.add(jScrollPane3);
        jScrollPane3.setBounds(60, 420, 320, 90);

        customerIDTxt.setEditable(false);
        customerIDTxt.setColumns(14);
        customerIDTxt.setText("0");
        customerIDTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customerIDTxtActionPerformed(evt);
            }
        });
        jPanel2.add(customerIDTxt);
        customerIDTxt.setBounds(250, 140, 140, 30);

        jLabel27.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(153, 51, 0));
        jLabel27.setText("CART");
        jPanel2.add(jLabel27);
        jLabel27.setBounds(60, 380, 190, 34);

        jLabel28.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(153, 51, 0));
        jLabel28.setText("PRODUCT LIST");
        jPanel2.add(jLabel28);
        jLabel28.setBounds(460, 130, 190, 34);

        jLabel29.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(153, 51, 0));
        jLabel29.setText("BILL LIST");
        jPanel2.add(jLabel29);
        jLabel29.setBounds(460, 290, 190, 34);

        rSLabelImage7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/backbtn.png"))); // NOI18N
        rSLabelImage7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSLabelImage7MouseClicked(evt);
            }
        });
        jPanel2.add(rSLabelImage7);
        rSLabelImage7.setBounds(10, 10, 45, 40);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Name");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(90, 180, 49, 21);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/logobakery.jpg"))); // NOI18N
        jPanel2.add(jLabel2);
        jLabel2.setBounds(670, 10, 320, 110);

        jLabel22.setBackground(new java.awt.Color(204, 102, 0));
        jLabel22.setFont(new java.awt.Font("Tahoma", 3, 27)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(102, 0, 0));
        jLabel22.setText("CUSTOMER PANEL");
        jPanel2.add(jLabel22);
        jLabel22.setBounds(120, 40, 320, 33);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 991, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 494, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void billListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_billListMouseClicked
        // Get the index of the clicked item
        int selectedIndex = billList.getSelectedIndex();

        // If an item is selected, display its details in the relevant text fields
        if (selectedIndex != -1) {
            String selectedItem = billList.getModel().getElementAt(selectedIndex);
            nameTxt.setText(selectedItem); // Assuming this is a field showing the item name

            // You can also populate other fields with information based on the selected item
            // For example, if you have a method to get product details by name, use it here
            Product selectedProduct = productDAO.getProductByName(selectedItem);
            
            if (selectedProduct != null) {
                priceTxt.setText(String.valueOf(selectedProduct.getPrice())); // Display the product price
                quantityBox.setSelectedIndex(0); // Reset quantity selection or set default
            }
        }
    }//GEN-LAST:event_billListMouseClicked

    private void billListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_billListValueChanged
        // Check if there's a selection in the bill list
        boolean isItemSelected = !billList.isSelectionEmpty();

        // Enable or disable buttons based on whether an item is selected
        addButton.setEnabled(isItemSelected);
        removeButton.setEnabled(isItemSelected);

        // You can also use this event to update other parts of the UI
        if (isItemSelected) {
            int selectedIndex = billList.getSelectedIndex();
            String selectedItem = billList.getModel().getElementAt(selectedIndex);

            // Display details of the selected item in other UI components
            nameTxt.setText(selectedItem);

            // Assuming you have a way to get product details by name
            Product selectedProduct = productDAO.getProductByName(selectedItem);
            
            if (selectedProduct != null) {
                priceTxt.setText(String.valueOf(selectedProduct.getPrice()));
                quantityBox.setSelectedIndex(0);
            }
        }
    }//GEN-LAST:event_billListValueChanged

    private void pruductTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pruductTableMouseClicked
        int selectedRow = pruductTable.getSelectedRow();
        
        if (selectedRow >= 0) {
            // Ensure correct data type casting
            String productName = (String) pruductTable.getValueAt(selectedRow, 0); // Product name (String)
            double productPrice = Double.parseDouble(pruductTable.getValueAt(selectedRow, 1).toString()); // Product price (Double)

            // Set the retrieved values in the appropriate text fields or other UI elements
            nameTxt.setText(productName);
            priceTxt.setText(String.format("%.2f", productPrice));
            
        }

    }//GEN-LAST:event_pruductTableMouseClicked

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        try {
            String productName = nameTxt.getText();
            double productPrice = Double.parseDouble(priceTxt.getText());
            int quantity = Integer.parseInt(quantityBox.getSelectedItem().toString());
            
            if (productName.isEmpty() || productPrice < 0 || quantity <= 0) {
                throw new IllegalArgumentException("Invalid product details. Please ensure name, price, and quantity are correctly entered.");
            }
            
            Object[] row = {
                productName,
                productPrice, // Ensure price is in correct format
                quantity // Product stock
            };
            cartTableModel.addRow(row);

            // Update the total label after adding
            updateTotalLabel();
            // Clear the text fields and reset the combo box
            nameTxt.setText("");
            priceTxt.setText("");
            quantityBox.setSelectedIndex(0);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number for price and quantity.");
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_addButtonActionPerformed
    // Calculate and update the total amount label

    private void updateTotalLabel() {
        if (cartTableModel == null) {
            throw new IllegalStateException("Cart Table Model is not initialized.");
        }
        
        double total = 0.0;
        for (int i = 0; i < cartTableModel.getRowCount(); i++) {
            Object priceObj = cartTableModel.getValueAt(i, 1);
            Object quantityObj = cartTableModel.getValueAt(i, 2);
            
            if (priceObj == null || quantityObj == null) {
                throw new IllegalStateException("Price or quantity in cart table is null.");
            }
            
            double price = Double.parseDouble(priceObj.toString());
            int quantity = Integer.parseInt(quantityObj.toString());
            total += price * quantity; // Calculate total
        }
        
        priceLabel.setText(String.format("Total: $%.2f", total));
    }
    

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        // TODO add your handling code here:
        nameTxt.setText("");
        priceTxt.setText("");

    }//GEN-LAST:event_clearButtonActionPerformed

    private void removeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeButtonActionPerformed
        int selectedRowIndex = cartTable.getSelectedRow(); // Get the selected row
        if (selectedRowIndex != -1) {
            cartTableModel.removeRow(selectedRowIndex); // Remove the selected row
            updateTotalLabel(); // Update the total label after removal
        } else {
            JOptionPane.showMessageDialog(this, "Please select a product to remove from the cart.");
        }

    }//GEN-LAST:event_removeButtonActionPerformed

    private void checkoutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkoutButtonActionPerformed
        checkout();

    }//GEN-LAST:event_checkoutButtonActionPerformed

    private void cartTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cartTableMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_cartTableMouseClicked

    private void customerIDTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customerIDTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_customerIDTxtActionPerformed

    private void rSLabelImage7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSLabelImage7MouseClicked
        Login ap = new Login();
        ap.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_rSLabelImage7MouseClicked
    
    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CustomerPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CustomerPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CustomerPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CustomerPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }


        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerPanel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JList<String> billList;
    private javax.swing.JTable cartTable;
    private javax.swing.JButton checkoutButton;
    private javax.swing.JButton clearButton;
    private javax.swing.JTextField customerIDTxt;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField nameTxt;
    private javax.swing.JLabel priceLabel;
    private javax.swing.JTextField priceTxt;
    private javax.swing.JTable pruductTable;
    private javax.swing.JComboBox<String> quantityBox;
    private rojerusan.RSLabelImage rSLabelImage7;
    private javax.swing.JButton removeButton;
    // End of variables declaration//GEN-END:variables
}
