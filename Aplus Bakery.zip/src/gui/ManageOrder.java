package gui;

import DataBase.CartDAO;
import DataBase.PaymentDAO;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Cart;

public class ManageOrder extends javax.swing.JFrame {

    private CartDAO cartDAO; // DAO for accessing cart data
 private PaymentDAO paymentDAO; 
    public ManageOrder() {
        initComponents();
        cartDAO = new CartDAO();
          paymentDAO = new PaymentDAO();
        fillTable();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addWindowListener(
                new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent event) {

            }
        }
        );
    }

  public void fillTable() {
        List<Cart> carts = cartDAO.getAllCarts();
        DefaultTableModel tableModel = (DefaultTableModel) orderTable.getModel();
        tableModel.setRowCount(0);

        for (Cart cart : carts) {
            int orderId = cart.getOrderId();

            Object[] row = {
                cart.getOrderId(),
                cart.getCustomerId(),
                paymentDAO.getPaymentAmount(orderId), // Retrieve the payment amount for this order
                cartDAO.getNumberOfItems(orderId) // Retrieve the number of items for this order
            };

            tableModel.addRow(row);
        }
    }

// Calculate the total amount for a cart

    private double calculateTotalAmount(Cart cart) {
        // Implement the logic to calculate total amount
        return 0.0; // Placeholder implementation
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jProgressBar1 = new javax.swing.JProgressBar();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        CustIDfield = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        orderTable = new javax.swing.JTable();
        searchButton = new javax.swing.JButton();
        removeButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        orderIDfield = new javax.swing.JTextField();
        refreshButton = new javax.swing.JButton();
        rSLabelImage6 = new rojerusan.RSLabelImage();
        jLabel20 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Aplus Bakery - Manage Orders");
        setMaximumSize(new java.awt.Dimension(968, 623));
        setMinimumSize(new java.awt.Dimension(968, 623));
        setPreferredSize(new java.awt.Dimension(968, 623));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Search Customer's Orders");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(180, 180, 181, 17);

        CustIDfield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CustIDfieldActionPerformed(evt);
            }
        });
        jPanel2.add(CustIDfield);
        CustIDfield.setBounds(380, 180, 271, 40);

        orderTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Order_ID", "Customer_ID", "TotalAmount", "NumberOfItem"
            }
        ));
        orderTable.setSelectionBackground(new java.awt.Color(204, 204, 255));
        orderTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                orderTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(orderTable);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(80, 420, 818, 91);

        searchButton.setBackground(new java.awt.Color(102, 0, 0));
        searchButton.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        searchButton.setForeground(new java.awt.Color(255, 255, 255));
        searchButton.setText("SEARCH");
        searchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchButtonActionPerformed(evt);
            }
        });
        jPanel2.add(searchButton);
        searchButton.setBounds(690, 180, 110, 40);

        removeButton.setBackground(new java.awt.Color(102, 0, 0));
        removeButton.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        removeButton.setForeground(new java.awt.Color(255, 255, 255));
        removeButton.setText("REMOVE");
        removeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeButtonActionPerformed(evt);
            }
        });
        jPanel2.add(removeButton);
        removeButton.setBounds(690, 370, 103, 40);

        clearButton.setBackground(new java.awt.Color(102, 0, 0));
        clearButton.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        clearButton.setForeground(new java.awt.Color(255, 255, 255));
        clearButton.setText("CLEAR");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });
        jPanel2.add(clearButton);
        clearButton.setBounds(810, 370, 87, 40);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Order Id");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(180, 240, 60, 17);

        orderIDfield.setEditable(false);
        orderIDfield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orderIDfieldActionPerformed(evt);
            }
        });
        jPanel2.add(orderIDfield);
        orderIDfield.setBounds(380, 240, 271, 40);

        refreshButton.setBackground(new java.awt.Color(102, 0, 0));
        refreshButton.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        refreshButton.setForeground(new java.awt.Color(255, 255, 255));
        refreshButton.setText("REFRESH");
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });
        jPanel2.add(refreshButton);
        refreshButton.setBounds(690, 240, 110, 40);

        rSLabelImage6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/backbtn.png"))); // NOI18N
        rSLabelImage6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSLabelImage6MouseClicked(evt);
            }
        });
        jPanel2.add(rSLabelImage6);
        rSLabelImage6.setBounds(10, 10, 45, 40);

        jLabel20.setBackground(new java.awt.Color(204, 102, 0));
        jLabel20.setFont(new java.awt.Font("Tahoma", 3, 27)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(102, 0, 0));
        jLabel20.setText("MANAGE ORDERS");
        jPanel2.add(jLabel20);
        jLabel20.setBounds(120, 50, 300, 33);

        jLabel27.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(153, 51, 0));
        jLabel27.setText("ORDER LIST");
        jPanel2.add(jLabel27);
        jLabel27.setBounds(90, 370, 190, 34);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/logobakery.jpg"))); // NOI18N
        jPanel2.add(jLabel2);
        jLabel2.setBounds(600, 10, 320, 110);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 968, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 601, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(984, 640));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void CustIDfieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CustIDfieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CustIDfieldActionPerformed

    private void searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonActionPerformed
        try {
            int customerId = Integer.parseInt(CustIDfield.getText().trim());
            List<Cart> carts = cartDAO.getCartsByCustomerId(customerId); // Fetch orders for the customer
            DefaultTableModel tableModel = (DefaultTableModel) orderTable.getModel();
            tableModel.setRowCount(0); // Clear the existing rows

            for (Cart cart : carts) {
                Object[] row = {
                    cart.getOrderId(),
                    cart.getCustomerId(),
                    calculateTotalAmount(cart),
                    cartDAO.getNumberOfItems(cart.getOrderId())
                };
                tableModel.addRow(row); // Add the row to the table
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid customer ID.", "Error", JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_searchButtonActionPerformed

    private void removeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeButtonActionPerformed
        int selectedRow = orderTable.getSelectedRow(); // Get the selected row
        if (selectedRow >= 0) {
            int orderId = (int) orderTable.getValueAt(selectedRow, 0); // Get the order ID
            cartDAO.deleteCart(orderId); // Delete the order from the database
            fillTable(); // Refresh the table after removal
            JOptionPane.showMessageDialog(this, "Order removed successfully.");
        } else {
            JOptionPane.showMessageDialog(this, "Please select an order to remove.", "Warning", JOptionPane.WARNING_MESSAGE);
        }


    }//GEN-LAST:event_removeButtonActionPerformed

    private void orderIDfieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orderIDfieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_orderIDfieldActionPerformed

    private void orderTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_orderTableMouseClicked

    }//GEN-LAST:event_orderTableMouseClicked

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        CustIDfield.setText("Enter ID of Customer");
        orderIDfield.setText("");
    }//GEN-LAST:event_clearButtonActionPerformed

    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        fillTable();
    }//GEN-LAST:event_refreshButtonActionPerformed

    private void rSLabelImage6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSLabelImage6MouseClicked
        Admin_Panel ap = new Admin_Panel();
        ap.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_rSLabelImage6MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageOrder().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField CustIDfield;
    private javax.swing.JButton clearButton;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField orderIDfield;
    private javax.swing.JTable orderTable;
    private rojerusan.RSLabelImage rSLabelImage6;
    private javax.swing.JButton refreshButton;
    private javax.swing.JButton removeButton;
    private javax.swing.JButton searchButton;
    // End of variables declaration//GEN-END:variables
}
