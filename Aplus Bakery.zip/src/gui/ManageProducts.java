/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import DataBase.ProductDAO;
import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.sql.*;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import model.Product;

public class ManageProducts extends javax.swing.JFrame {

    private ProductDAO productDAO; // Data Access Object for managing products
    private DefaultTableModel productTableModel; // Table model for displaying products

    public ManageProducts() {
        initComponents();

        productDAO = new ProductDAO(); // Initialize the ProductDAO
        productTableModel = (DefaultTableModel) foodTable.getModel(); // Reference to the JTable's model
        fillTable(); // Populate the table with products from the database
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addWindowListener(
                new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent event) {

            }
        }
        );
    }

    // Fill the JTable with products from the database
    public void fillTable() {
        productTableModel.setRowCount(0); // Clear existing rows
        List<Product> products = productDAO.getAllProducts(); // Get all products from the database
        for (Product product : products) {
            Object[] row = {
                product.getProductId(), // Product ID
                product.getProductName(), // Product Name
                product.getStock(), // Stock
                product.getPrice() // Price
            };
            productTableModel.addRow(row); // Add row to the table model
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        foodIDTxt = new javax.swing.JTextField();
        nameTxt = new javax.swing.JTextField();
        typeTxt = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        foodTable = new javax.swing.JTable();
        addButton = new javax.swing.JButton();
        removeButton = new javax.swing.JButton();
        editButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        quantTxt = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        rSLabelImage6 = new rojerusan.RSLabelImage();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Aplus Bakery - Manage Products");
        setMinimumSize(new java.awt.Dimension(900, 550));
        setResizable(false);

        jPanel5.setBackground(new java.awt.Color(204, 204, 255));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setLayout(null);

        jLabel20.setBackground(new java.awt.Color(204, 102, 0));
        jLabel20.setFont(new java.awt.Font("Tahoma", 3, 27)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(102, 0, 0));
        jLabel20.setText("MANAGE PRODUCTS");
        jPanel6.add(jLabel20);
        jLabel20.setBounds(120, 50, 300, 33);

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel21.setText("Name");
        jPanel6.add(jLabel21);
        jLabel21.setBounds(150, 170, 40, 17);

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel22.setText("Product Id");
        jPanel6.add(jLabel22);
        jLabel22.setBounds(150, 130, 75, 17);

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel25.setText("Quantity");
        jPanel6.add(jLabel25);
        jLabel25.setBounds(490, 170, 80, 17);

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel26.setText("Price");
        jPanel6.add(jLabel26);
        jLabel26.setBounds(490, 130, 40, 17);

        foodIDTxt.setEditable(false);
        foodIDTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                foodIDTxtActionPerformed(evt);
            }
        });
        jPanel6.add(foodIDTxt);
        foodIDTxt.setBounds(260, 130, 160, 30);
        jPanel6.add(nameTxt);
        nameTxt.setBounds(260, 170, 160, 30);
        jPanel6.add(typeTxt);
        typeTxt.setBounds(580, 130, 160, 30);

        foodTable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 0, 0)));
        foodTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Food_ID", "Name", "Price", "Quantity"
            }
        ));
        foodTable.setSelectionBackground(new java.awt.Color(204, 204, 255));
        foodTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                foodTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(foodTable);

        jPanel6.add(jScrollPane3);
        jScrollPane3.setBounds(50, 300, 818, 239);

        addButton.setBackground(new java.awt.Color(102, 0, 0));
        addButton.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        addButton.setForeground(new java.awt.Color(255, 255, 255));
        addButton.setText("ADD");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        jPanel6.add(addButton);
        addButton.setBounds(420, 250, 96, 40);

        removeButton.setBackground(new java.awt.Color(102, 0, 0));
        removeButton.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        removeButton.setForeground(new java.awt.Color(255, 255, 255));
        removeButton.setText("REMOVE");
        removeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeButtonActionPerformed(evt);
            }
        });
        jPanel6.add(removeButton);
        removeButton.setBounds(650, 250, 100, 40);

        editButton.setBackground(new java.awt.Color(102, 0, 0));
        editButton.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        editButton.setForeground(new java.awt.Color(255, 255, 255));
        editButton.setText("EDIT");
        editButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editButtonActionPerformed(evt);
            }
        });
        jPanel6.add(editButton);
        editButton.setBounds(530, 250, 100, 40);

        clearButton.setBackground(new java.awt.Color(102, 0, 0));
        clearButton.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        clearButton.setForeground(new java.awt.Color(255, 255, 255));
        clearButton.setText("CLEAR");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });
        jPanel6.add(clearButton);
        clearButton.setBounds(770, 250, 100, 40);
        jPanel6.add(quantTxt);
        quantTxt.setBounds(580, 170, 160, 30);

        jLabel27.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(153, 51, 0));
        jLabel27.setText("PRODUCT LIST");
        jPanel6.add(jLabel27);
        jLabel27.setBounds(50, 250, 190, 34);

        rSLabelImage6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/backbtn.png"))); // NOI18N
        rSLabelImage6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSLabelImage6MouseClicked(evt);
            }
        });
        jPanel6.add(rSLabelImage6);
        rSLabelImage6.setBounds(10, 10, 45, 40);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/logobakery.jpg"))); // NOI18N
        jPanel6.add(jLabel2);
        jLabel2.setBounds(600, 10, 320, 110);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 915, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 561, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(914, 587));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void foodIDTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_foodIDTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_foodIDTxtActionPerformed

    private void foodTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_foodTableMouseClicked
        int selectedRow = foodTable.getSelectedRow();
        if (selectedRow >= 0) {
            foodIDTxt.setText(String.valueOf(productTableModel.getValueAt(selectedRow, 0))); // Product ID
            nameTxt.setText(String.valueOf(productTableModel.getValueAt(selectedRow, 1))); // Product Name
            quantTxt.setText(String.valueOf(productTableModel.getValueAt(selectedRow, 2))); // Stock
            typeTxt.setText(String.valueOf(productTableModel.getValueAt(selectedRow, 3))); // Price
        }
    }//GEN-LAST:event_foodTableMouseClicked

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        String productName = nameTxt.getText().trim();
        int stock = Integer.parseInt(quantTxt.getText().trim());
        double price = Double.parseDouble(typeTxt.getText().trim());

        // Create a new Product object
        Product newProduct = new Product(0, productName, stock, price);

        // Save the new product to the database
        productDAO.createProduct(newProduct);

        // Refresh the table after adding a new product
        fillTable();
        JOptionPane.showMessageDialog(this, "Product added successfully!");
    }//GEN-LAST:event_addButtonActionPerformed

    private void removeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeButtonActionPerformed
        int selectedRow = foodTable.getSelectedRow(); // Get the selected row
        if (selectedRow >= 0) {
            int productId = (int) productTableModel.getValueAt(selectedRow, 0); // Get Product ID

            // Delete the product from the database
            productDAO.deleteProduct(productId);

            fillTable(); // Refresh the table after deleting
            JOptionPane.showMessageDialog(this, "Product removed successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Please select a product to remove.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_removeButtonActionPerformed

    private void editButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editButtonActionPerformed
        int selectedRow = foodTable.getSelectedRow(); // Get the selected row
        if (selectedRow >= 0) {
            int productId = (int) productTableModel.getValueAt(selectedRow, 0); // Get Product ID
            String productName = nameTxt.getText().trim();
            int stock = Integer.parseInt(quantTxt.getText().trim());
            double price = Double.parseDouble(typeTxt.getText().trim());

            Product updatedProduct = new Product(productId, productName, stock, price);

            // Update the product in the database
            productDAO.updateProduct(updatedProduct);

            fillTable(); // Refresh the table after editing
            JOptionPane.showMessageDialog(this, "Product updated successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Please select a product to edit.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_editButtonActionPerformed


    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        // TODO add your handling code here:

        foodIDTxt.setText("");
        nameTxt.setText("");
        typeTxt.setText("");
        quantTxt.setText("");

    }//GEN-LAST:event_clearButtonActionPerformed

    private void rSLabelImage6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSLabelImage6MouseClicked
        Admin_Panel ap = new Admin_Panel();
        ap.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_rSLabelImage6MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageProducts.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageProducts.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageProducts.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageProducts.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageProducts().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JButton clearButton;
    private javax.swing.JButton editButton;
    private javax.swing.JTextField foodIDTxt;
    private javax.swing.JTable foodTable;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField nameTxt;
    private javax.swing.JTextField quantTxt;
    private rojerusan.RSLabelImage rSLabelImage6;
    private javax.swing.JButton removeButton;
    private javax.swing.JTextField typeTxt;
    // End of variables declaration//GEN-END:variables
}
