package gui;

import DataBase.EmployeeDAO;
import DataBase.ManagesDAO;
import DataBase.ProductDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Employee;
import model.Manages;
import model.Product;

public class ManagesManagementFrame extends javax.swing.JFrame {

    private ManagesDAO managesDAO;
    private DefaultTableModel tableModel;
    private ProductDAO productDAO;
    private EmployeeDAO employeeDAO;

    public ManagesManagementFrame() {
        initComponents();

        managesDAO = new ManagesDAO(); // Initialize the DAO
        managesDAO = new ManagesDAO(); // Initialize the DAO for Manages
        productDAO = new ProductDAO(); // Initialize the DAO for Products
        employeeDAO = new EmployeeDAO();
        tableModel = (DefaultTableModel) managesTable.getModel(); // Get the table model

        loadManages(); // Load existing data into the table
        loadProducts(); // Load products into the JComboBox
        loadEmployees();

        addButon.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                addManages();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                updateManages();
            }
        });

        deletebutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                deleteManages();
            }
        });
    }

    private void loadEmployees() {
        employeeIdTxt.removeAllItems(); // Clear existing items
        List<Employee> employees = employeeDAO.getAllEmployees(); // Fetch all employees

        for (Employee employee : employees) {
            employeeIdTxt.addItem(employee.getEmployeeId() + ": " + employee.getFirstName() + " " + employee.getLastName()); // Add to JComboBox
        }
    }

    private void loadManages() {
        tableModel.setRowCount(0); // Clear existing rows

        List<Manages> managesList = managesDAO.getAllManages();
        for (Manages manages : managesList) {
            tableModel.addRow(new Object[]{
                manages.getEmployeeFirstName() + " " + manages.getEmployeeLastName(),
                manages.getProductName()
            });
        }
    }

    private void loadProducts() {
        productIdTxt.removeAllItems(); // Clear existing items
        List<Product> products = productDAO.getAllProducts(); // Fetch all products

        for (Product product : products) {
            productIdTxt.addItem(product.getProductId() + ": " + product.getProductName()); // Add to JComboBox
        }
    }

    private void addManages() {
        try {
            String selectedEmployee = employeeIdTxt.getSelectedItem().toString();
            int employeeId = Integer.parseInt(selectedEmployee.split(":")[0].trim()); // Extract the ID from the string

            String selectedProduct = productIdTxt.getSelectedItem().toString();
            int productId = Integer.parseInt(selectedProduct.split(":")[0].trim()); // Extract the ID from the string

            Manages manages = new Manages(employeeId, productId, null, null);
            managesDAO.createManages(manages);

            tableModel.addRow(new Object[]{selectedEmployee, selectedProduct}); // Display in the table

            clearInputFields(); // Clear input fields after addition
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error adding record: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateManages() {
        try {
            int employeeId = Integer.parseInt(employeeIdTxt.getSelectedItem().toString());
            int productId = Integer.parseInt(productIdTxt.getSelectedItem().toString());

            Manages manages = new Manages(employeeId, productId, null, null);
            managesDAO.updateManages(manages);

            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if ((int) tableModel.getValueAt(i, 0) == employeeId
                        && (int) tableModel.getValueAt(i, 1) == productId) {
                    tableModel.setValueAt(employeeId, i, 0);
                    tableModel.setValueAt(productId, i, 1);
                    break;
                }
            }

            clearInputFields(); // Clear input fields after updating
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error updating record: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteManages() {
        try {
            int employeeId = Integer.parseInt(employeeIdTxt.getSelectedItem().toString());
            int productId = Integer.parseInt(productIdTxt.getSelectedItem().toString());

            managesDAO.deleteManages(employeeId, productId);

            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if ((int) tableModel.getValueAt(i, 0) == employeeId
                        && (int) tableModel.getValueAt(i, 1) == productId) {
                    tableModel.removeRow(i);
                    break;
                }
            }

            clearInputFields(); // Clear input fields after deletion
        } catch (Exception ex) {
            
            JOptionPane.showMessageDialog(this, "Error deleting record: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearInputFields() {

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollBar1 = new javax.swing.JScrollBar();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        managesTable = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        employeeIdTxt = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        productIdTxt = new javax.swing.JComboBox<>();
        addButon = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deletebutton = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        rSLabelImage7 = new rojerusan.RSLabelImage();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Aplus Bakery - Management");
        setMinimumSize(new java.awt.Dimension(968, 623));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        jPanel3.setBackground(new java.awt.Color(153, 153, 255));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setLayout(null);

        managesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Employee", "Products"
            }
        ));
        jScrollPane1.setViewportView(managesTable);

        jPanel5.add(jScrollPane1);
        jScrollPane1.setBounds(90, 340, 790, 220);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Employee ID");
        jPanel5.add(jLabel2);
        jLabel2.setBounds(320, 150, 97, 17);

        employeeIdTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel5.add(employeeIdTxt);
        employeeIdTxt.setBounds(480, 150, 160, 30);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Product ID");
        jPanel5.add(jLabel3);
        jLabel3.setBounds(320, 200, 97, 17);

        productIdTxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel5.add(productIdTxt);
        productIdTxt.setBounds(480, 200, 160, 30);

        addButon.setBackground(new java.awt.Color(102, 0, 0));
        addButon.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        addButon.setForeground(new java.awt.Color(255, 255, 255));
        addButon.setText("Add");
        addButon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButonActionPerformed(evt);
            }
        });
        jPanel5.add(addButon);
        addButon.setBounds(320, 260, 91, 38);

        updateButton.setBackground(new java.awt.Color(102, 0, 0));
        updateButton.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        updateButton.setForeground(new java.awt.Color(255, 255, 255));
        updateButton.setText("EDIT");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });
        jPanel5.add(updateButton);
        updateButton.setBounds(430, 260, 100, 40);

        deletebutton.setBackground(new java.awt.Color(102, 0, 0));
        deletebutton.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        deletebutton.setForeground(new java.awt.Color(255, 255, 255));
        deletebutton.setText("REMOVE");
        deletebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebuttonActionPerformed(evt);
            }
        });
        jPanel5.add(deletebutton);
        deletebutton.setBounds(550, 260, 89, 40);

        jLabel21.setBackground(new java.awt.Color(204, 102, 0));
        jLabel21.setFont(new java.awt.Font("Tahoma", 3, 27)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(102, 0, 0));
        jLabel21.setText("MANAGE BAKERY");
        jPanel5.add(jLabel21);
        jLabel21.setBounds(110, 30, 260, 33);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/logobakery.jpg"))); // NOI18N
        jPanel5.add(jLabel4);
        jLabel4.setBounds(640, 0, 320, 110);

        rSLabelImage7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/backbtn.png"))); // NOI18N
        rSLabelImage7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSLabelImage7MouseClicked(evt);
            }
        });
        jPanel5.add(rSLabelImage7);
        rSLabelImage7.setBounds(10, 10, 45, 40);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, 961, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, 491, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void addButonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButonActionPerformed

    }//GEN-LAST:event_addButonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
updateManages();
    }//GEN-LAST:event_updateButtonActionPerformed

    private void deletebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebuttonActionPerformed

    }//GEN-LAST:event_deletebuttonActionPerformed

    private void rSLabelImage7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSLabelImage7MouseClicked
        Admin_Panel ap = new Admin_Panel();
        ap.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_rSLabelImage7MouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagesManagementFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManagesManagementFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManagesManagementFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManagesManagementFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManagesManagementFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButon;
    private javax.swing.JButton deletebutton;
    private javax.swing.JComboBox<String> employeeIdTxt;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollBar jScrollBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable managesTable;
    private javax.swing.JComboBox<String> productIdTxt;
    private rojerusan.RSLabelImage rSLabelImage7;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables
}
