package gui;

public class Admin_Panel extends javax.swing.JFrame {

    /**
     * Creates new form Admin_Panel
     */
    public Admin_Panel() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        rSLabelImage1 = new rojerusan.RSLabelImage();
        jLabel15 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        rSLabelImage3 = new rojerusan.RSLabelImage();
        jPanel8 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        rSLabelImage4 = new rojerusan.RSLabelImage();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        rSLabelImage5 = new rojerusan.RSLabelImage();
        jLabel8 = new javax.swing.JLabel();
        LogoutButton1 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Aplus Bakery - Admin");
        setMinimumSize(new java.awt.Dimension(968, 623));
        setResizable(false);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(102, 0, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 0, 0));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("PRODUCT MANAGEMENT");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel4.add(jLabel2);
        jLabel2.setBounds(0, 130, 280, 41);

        rSLabelImage1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/bakery products.png"))); // NOI18N
        rSLabelImage1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSLabelImage1MouseClicked(evt);
            }
        });
        rSLabelImage1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                rSLabelImage1KeyPressed(evt);
            }
        });
        jPanel4.add(rSLabelImage1);
        rSLabelImage1.setBounds(40, 10, 210, 120);

        jLabel15.setFont(new java.awt.Font("Century Gothic", 0, 27)); // NOI18N
        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/petscare/Icon/account.png"))); // NOI18N
        jLabel15.setText(" ADMIN");
        jPanel4.add(jLabel15);
        jLabel15.setBounds(340, 20, 165, 64);

        jPanel1.add(jPanel4);
        jPanel4.setBounds(330, 30, 280, 170);

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel7.setLayout(null);

        jLabel5.setBackground(new java.awt.Color(102, 0, 0));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 0, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("EMPLOYEE MANAGEMENT");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        jPanel7.add(jLabel5);
        jLabel5.setBounds(0, 130, 278, 41);

        rSLabelImage3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/empbakery.jpg"))); // NOI18N
        rSLabelImage3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSLabelImage3MouseClicked(evt);
            }
        });
        rSLabelImage3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                rSLabelImage3KeyPressed(evt);
            }
        });
        jPanel7.add(rSLabelImage3);
        rSLabelImage3.setBounds(60, 10, 170, 130);

        jPanel1.add(jPanel7);
        jPanel7.setBounds(200, 390, 280, 170);

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel8.setLayout(null);

        jLabel6.setBackground(new java.awt.Color(102, 0, 0));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 0, 0));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("BAKERY MANAGEMENT");
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        jPanel8.add(jLabel6);
        jLabel6.setBounds(0, 130, 278, 36);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/bakerymanagement.png"))); // NOI18N
        jPanel8.add(jLabel1);
        jLabel1.setBounds(50, 0, 180, 140);

        jPanel1.add(jPanel8);
        jPanel8.setBounds(490, 210, 280, 170);

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel9.setLayout(null);

        jLabel7.setBackground(new java.awt.Color(102, 0, 0));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(102, 0, 0));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("MANAGE ORDERS");
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        jPanel9.add(jLabel7);
        jLabel7.setBounds(0, 130, 280, 41);

        rSLabelImage4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/bakery.png"))); // NOI18N
        rSLabelImage4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSLabelImage4MouseClicked(evt);
            }
        });
        rSLabelImage4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                rSLabelImage4KeyPressed(evt);
            }
        });
        jPanel9.add(rSLabelImage4);
        rSLabelImage4.setBounds(40, 10, 210, 120);

        jPanel1.add(jPanel9);
        jPanel9.setBounds(490, 390, 280, 170);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel5.setLayout(null);

        jLabel3.setBackground(new java.awt.Color(102, 0, 0));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 0, 0));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("CUSTOMER MANAGEMENT");
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        jPanel5.add(jLabel3);
        jLabel3.setBounds(0, 130, 280, 41);

        rSLabelImage5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/customer.png"))); // NOI18N
        rSLabelImage5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSLabelImage5MouseClicked(evt);
            }
        });
        rSLabelImage5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                rSLabelImage5KeyPressed(evt);
            }
        });
        jPanel5.add(rSLabelImage5);
        rSLabelImage5.setBounds(40, 10, 210, 130);

        jPanel1.add(jPanel5);
        jPanel5.setBounds(200, 210, 280, 170);
        jPanel1.add(jLabel8);
        jLabel8.setBounds(43, 34, 0, 0);

        LogoutButton1.setBackground(new java.awt.Color(255, 255, 255));
        LogoutButton1.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        LogoutButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/petscare/Icon/iconlogout.jpg"))); // NOI18N
        LogoutButton1.setText("LOGOUT");
        LogoutButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(LogoutButton1);
        LogoutButton1.setBounds(770, 20, 181, 90);

        jLabel21.setBackground(new java.awt.Color(204, 102, 0));
        jLabel21.setFont(new java.awt.Font("Tahoma", 3, 27)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(102, 0, 0));
        jLabel21.setText("ADMIN");
        jPanel1.add(jLabel21);
        jLabel21.setBounds(150, 60, 120, 33);
        jPanel1.add(jLabel9);
        jLabel9.setBounds(37, 34, 0, 0);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/logobakery.jpg"))); // NOI18N
        jPanel1.add(jLabel4);
        jLabel4.setBounds(10, 0, 320, 120);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(-10, 0, 990, 700);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void LogoutButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutButton1ActionPerformed
        // TODO add your handling code here:

        this.setVisible(false);
        Login login = new Login();
        login.setVisible(true);
    }//GEN-LAST:event_LogoutButton1ActionPerformed

    private void rSLabelImage5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rSLabelImage5KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_rSLabelImage5KeyPressed

    private void rSLabelImage5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSLabelImage5MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rSLabelImage5MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        ManageCustomer c=new ManageCustomer();
        //        CustomerPanel c = new CustomerPanel();
        c.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel3MouseClicked

    private void rSLabelImage4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rSLabelImage4KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_rSLabelImage4KeyPressed

    private void rSLabelImage4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSLabelImage4MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rSLabelImage4MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        ManageOrder sa = new ManageOrder();
        sa.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        ManagesManagementFrame mmf = new ManagesManagementFrame();
        mmf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel6MouseClicked

    private void rSLabelImage3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rSLabelImage3KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_rSLabelImage3KeyPressed

    private void rSLabelImage3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSLabelImage3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rSLabelImage3MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        ManageEmployee emp = new ManageEmployee();
        emp.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel5MouseClicked

    private void rSLabelImage1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rSLabelImage1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_rSLabelImage1KeyPressed

    private void rSLabelImage1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSLabelImage1MouseClicked
        Admin_Panel main = new Admin_Panel();
        main.setVisible(true);
        dispose();
    }//GEN-LAST:event_rSLabelImage1MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        ManageProducts pr = new ManageProducts();
        pr.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel2MouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin_Panel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin_Panel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin_Panel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin_Panel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin_Panel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LogoutButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private rojerusan.RSLabelImage rSLabelImage1;
    private rojerusan.RSLabelImage rSLabelImage3;
    private rojerusan.RSLabelImage rSLabelImage4;
    private rojerusan.RSLabelImage rSLabelImage5;
    // End of variables declaration//GEN-END:variables
}
