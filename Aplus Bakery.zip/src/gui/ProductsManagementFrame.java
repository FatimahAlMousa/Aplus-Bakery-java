package gui;

import DataBase.ProductDAO;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Product;

public class ProductsManagementFrame extends javax.swing.JFrame {

    private ProductDAO productDAO;
    private DefaultTableModel tableModel;

    public ProductsManagementFrame() {
        initComponents();
        productDAO = new ProductDAO(); // Initialize the DAO
        tableModel = (DefaultTableModel) jTable1.getModel(); // Get the table model
        loadProducts();
    }

    private void clearInputFields() {
        idTxt.setText("");
        nameTxt.setText("");
        stockTxt.setText("");
        priceTxt.setText("");
    }

    private void loadProducts() {
        tableModel.setRowCount(0); // Clear existing rows

        List<Product> products = productDAO.getAllProducts();
        for (Product product : products) {
            tableModel.addRow(new Object[]{product.getProductId(), product.getProductName(), product.getStock(), product.getPrice()});
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        idTxt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        nameTxt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        stockTxt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        priceTxt = new javax.swing.JTextField();
        addButon = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deletebutton = new javax.swing.JButton();
        rSLabelImage7 = new rojerusan.RSLabelImage();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        rSLabelImage6 = new rojerusan.RSLabelImage();
        jLabel7 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Aplus Bakery - Product Management");
        setMinimumSize(new java.awt.Dimension(968, 623));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(null);

        jLabel27.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(153, 51, 0));
        jLabel27.setText("PRODUCTS LIST");
        jPanel4.add(jLabel27);
        jLabel27.setBounds(470, 20, 190, 34);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText(" ID");
        jPanel4.add(jLabel2);
        jLabel2.setBounds(90, 30, 111, 20);

        idTxt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        idTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idTxtActionPerformed(evt);
            }
        });
        jPanel4.add(idTxt);
        idTxt.setBounds(220, 30, 150, 30);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Product Name");
        jPanel4.add(jLabel3);
        jLabel3.setBounds(90, 70, 123, 20);

        nameTxt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        nameTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameTxtActionPerformed(evt);
            }
        });
        jPanel4.add(nameTxt);
        nameTxt.setBounds(220, 70, 150, 30);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Product Stock");
        jPanel4.add(jLabel4);
        jLabel4.setBounds(90, 110, 123, 20);

        stockTxt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        stockTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stockTxtActionPerformed(evt);
            }
        });
        jPanel4.add(stockTxt);
        stockTxt.setBounds(220, 110, 150, 30);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Product Price");
        jPanel4.add(jLabel5);
        jLabel5.setBounds(90, 150, 123, 20);

        priceTxt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        priceTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                priceTxtActionPerformed(evt);
            }
        });
        jPanel4.add(priceTxt);
        priceTxt.setBounds(220, 150, 150, 30);

        addButon.setBackground(new java.awt.Color(102, 0, 0));
        addButon.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        addButon.setForeground(new java.awt.Color(255, 255, 255));
        addButon.setText("ADD");
        addButon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButonActionPerformed(evt);
            }
        });
        jPanel4.add(addButon);
        addButon.setBounds(90, 200, 80, 40);

        updateButton.setBackground(new java.awt.Color(102, 0, 0));
        updateButton.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        updateButton.setForeground(new java.awt.Color(255, 255, 255));
        updateButton.setText("EDIT");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });
        jPanel4.add(updateButton);
        updateButton.setBounds(180, 200, 80, 40);

        deletebutton.setBackground(new java.awt.Color(102, 0, 0));
        deletebutton.setFont(new java.awt.Font("Century Gothic", 3, 14)); // NOI18N
        deletebutton.setForeground(new java.awt.Color(255, 255, 255));
        deletebutton.setText("REMOVE");
        deletebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebuttonActionPerformed(evt);
            }
        });
        jPanel4.add(deletebutton);
        deletebutton.setBounds(270, 200, 100, 40);

        rSLabelImage7.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        rSLabelImage7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/delicious-cake-with-fruits-cream.jpg"))); // NOI18N
        jPanel4.add(rSLabelImage7);
        rSLabelImage7.setBounds(20, 250, 430, 211);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Product name", "Stock", "Price"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jPanel4.add(jScrollPane1);
        jScrollPane1.setBounds(470, 60, 450, 370);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 966, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 520, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(1, 102, 966, 520);

        rSLabelImage6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/backbtn.png"))); // NOI18N
        rSLabelImage6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSLabelImage6MouseClicked(evt);
            }
        });
        jPanel1.add(rSLabelImage6);
        rSLabelImage6.setBounds(10, 10, 71, 57);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/logobakery.jpg"))); // NOI18N
        jPanel1.add(jLabel7);
        jLabel7.setBounds(640, 0, 320, 110);

        jLabel21.setBackground(new java.awt.Color(204, 102, 0));
        jLabel21.setFont(new java.awt.Font("Tahoma", 3, 27)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(102, 0, 0));
        jLabel21.setText("PRODUCTS MANAGEMENT");
        jPanel1.add(jLabel21);
        jLabel21.setBounds(190, 30, 417, 33);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 968, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 623, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void rSLabelImage6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSLabelImage6MouseClicked
        Admin_Panel ap = new Admin_Panel();
        ap.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_rSLabelImage6MouseClicked

    private void deletebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebuttonActionPerformed
        try {
            int productId = Integer.parseInt(idTxt.getText());

            productDAO.deleteProduct(productId); // Delete from database

            // Find and remove the row in the table
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if ((int) tableModel.getValueAt(i, 0) == productId) {
                    tableModel.removeRow(i);
                    break;
                }
            }

            clearInputFields();

            JOptionPane.showMessageDialog(this, "Product deleted successfully!");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error deleting product: " + e.getMessage());
        }
    }//GEN-LAST:event_deletebuttonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        try {
            int productId = Integer.parseInt(idTxt.getText());
            String productName = nameTxt.getText();
            int stock = Integer.parseInt(stockTxt.getText());
            double price = Double.parseDouble(priceTxt.getText());

            Product product = new Product(productId, productName, stock, price);
            productDAO.updateProduct(product); // Update in database

            // Find and update the row in the table
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if ((int) tableModel.getValueAt(i, 0) == productId) {
                    tableModel.setValueAt(productName, i, 1);
                    tableModel.setValueAt(stock, i, 2);
                    tableModel.setValueAt(price, i, 3);
                    break;
                }
            }

            clearInputFields();

            JOptionPane.showMessageDialog(this, "Product updated successfully!");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating product: " + e.getMessage());
        }
    }//GEN-LAST:event_updateButtonActionPerformed

    private void addButonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButonActionPerformed
        try {
            int productId = Integer.parseInt(idTxt.getText());
            String productName = nameTxt.getText();
            int stock = Integer.parseInt(stockTxt.getText());
            double price = Double.parseDouble(priceTxt.getText());

            Product product = new Product(productId, productName, stock, price);
            productDAO.createProduct(product); // Save to database

            // Add to table and clear input fields
            tableModel.addRow(new Object[]{productId, productName, stock, price});
            clearInputFields();

            JOptionPane.showMessageDialog(this, "Product added successfully!");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error adding product: " + e.getMessage());
        }
    }//GEN-LAST:event_addButonActionPerformed

    private void priceTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_priceTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_priceTxtActionPerformed

    private void stockTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_stockTxtActionPerformed

    private void nameTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameTxtActionPerformed

    private void idTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idTxtActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ProductsManagementFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButon;
    private javax.swing.JButton deletebutton;
    private javax.swing.JTextField idTxt;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField nameTxt;
    private javax.swing.JTextField priceTxt;
    private rojerusan.RSLabelImage rSLabelImage6;
    private rojerusan.RSLabelImage rSLabelImage7;
    private javax.swing.JTextField stockTxt;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables
}
