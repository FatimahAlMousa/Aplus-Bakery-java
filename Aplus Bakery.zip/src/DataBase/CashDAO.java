package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Cash;

public class CashDAO {

    private Connection con;

    public CashDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new cash payment
    public void createCash(Cash cash) {
        try {
            String query = "INSERT INTO cash (cash_id) VALUES (?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, cash.getCashId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in createCash: " + ex.getMessage());
        }
    }

    // Retrieve a cash payment by ID
    public Cash getCash(int cashId) {
        Cash cash = null;
        try {
            String query = "SELECT * FROM cash WHERE cash_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, cashId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                cash = new Cash(rs.getInt("cash_id"), null);
            }
        } catch (SQLException ex) {
            System.out.println("Error in getCash: " + ex.getMessage());
        }
        return cash;
    }

    // Retrieve all cash payments
    public List<Cash> getAllCashes() {
        List<Cash> cashes = new ArrayList<>();
        try {
            String query = "SELECT * FROM cash";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                Cash cash = new Cash(rs.getInt("cash_id"), null);
                cashes.add(cash);
            }
        } catch (SQLException ex) {
            System.out.println("Error in getAllCashes: " + ex.getMessage());
        }
        return cashes;
    }

    // Update a cash payment
    public void updateCash(Cash cash) {
        try {
            String query = "UPDATE cash SET cash_id = ? WHERE cash_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, cash.getCashId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in updateCash: " + ex.getMessage());
        }
    }

    // Delete a cash payment
    public void deleteCash(int cashId) {
        try {
            String query = "DELETE FROM cash WHERE cash_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, cashId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in deleteCash: " + ex.getMessage());
        }
    }
}
