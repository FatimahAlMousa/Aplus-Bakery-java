package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Cake;

public class CakeDAO {

    private Connection con;

    public CakeDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new cake
    public void createCake(Cake cake) {
        try {
            String query = "INSERT INTO cake (cake_id, CakeType) VALUES (?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, cake.getCakeId());
            stmt.setString(2, cake.getCakeType());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in createCake: " + ex.getMessage());
        }
    }

    // Retrieve a cake by ID
    public Cake getCake(int cakeId) {
        Cake cake = null;
        try {
            String query = "SELECT * FROM cake WHERE cake_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, cakeId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                cake = new Cake(rs.getInt("cake_id"), rs.getString("CakeType"), null);
            }
        } catch (SQLException ex) {
            System.out.println("Error in getCake: " + ex.getMessage());
        }
        return cake;
    }

    // Retrieve all cakes
    public List<Cake> getAllCakes() {
        List<Cake> cakes = new ArrayList<>();
        try {
            String query = "SELECT * FROM cake";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                Cake cake = new Cake(rs.getInt("cake_id"), rs.getString("CakeType"), null);
                cakes.add(cake);
            }
        } catch (SQLException ex) {
            System.out.println("Error in getAllCakes: " + ex.getMessage());
        }
        return cakes;
    }

    // Update a cake
    public void updateCake(Cake cake) {
        try {
            String query = "UPDATE cake SET CakeType = ? WHERE cake_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, cake.getCakeType());
            stmt.setInt(2, cake.getCakeId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in updateCake: " + ex.getMessage());
        }
    }

    // Delete a cake
    public void deleteCake(int cakeId) {
        try {
            String query = "DELETE FROM cake WHERE cake_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, cakeId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in deleteCake: " + ex.getMessage());

        }
    }
}
