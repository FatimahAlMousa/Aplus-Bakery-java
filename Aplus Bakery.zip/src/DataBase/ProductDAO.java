package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Product;

public class ProductDAO {

    private Connection con;

    public ProductDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new product
    public void createProduct(Product product) {
        try {
            String query = "INSERT INTO product (Prod_id, Prod_name, stock, price) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, product.getProductId());
            stmt.setString(2, product.getProductName());
            stmt.setInt(3, product.getStock());
            stmt.setDouble(4, product.getPrice());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in createProduct: " + ex.getMessage());
        }
    }

    // Retrieve a product by ID
    public Product getProduct(int productId) {
        Product product = null;
        try {
            String query = "SELECT * FROM product WHERE Prod_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                product = new Product(
                        rs.getInt("Prod_id"),
                        rs.getString("Prod_name"),
                        rs.getInt("stock"),
                        rs.getDouble("price")
                );
            }
        } catch (SQLException ex) {
            System.out.println("Error in getProduct: " + ex.getMessage());
        }
        return product;
    }

    // Retrieve all products
    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        try {
            String query = "SELECT * FROM product";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                Product product = new Product(
                        rs.getInt("Prod_id"),
                        rs.getString("Prod_name"),
                        rs.getInt("stock"),
                        rs.getDouble("price")
                );
                products.add(product);
            }
        } catch (SQLException ex) {
            System.out.println("Error in getAllProducts: " + ex.getMessage());
        }
        return products;
    }

    // Update a product
    public void updateProduct(Product product) {
        try {
            String query = "UPDATE product SET Prod_name = ?, stock = ?, price = ? WHERE Prod_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, product.getProductName());
            stmt.setInt(2, product.getStock());
            stmt.setDouble(3, product.getPrice());
            stmt.setInt(4, product.getProductId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in updateProduct: " + ex.getMessage());
        }
    }

    // Delete a product
    public void deleteProduct(int productId) {
        try {
            String query = "DELETE FROM product WHERE Prod_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, productId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in deleteProduct: " + ex.getMessage());
        }
    }
    
    // Retrieve a product by name
    public Product getProductByName(String productName) {
        Product product = null;
        try {
            String query = "SELECT * FROM product WHERE Prod_name = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, productName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                product = new Product(
                        rs.getInt("Prod_id"),
                        rs.getString("Prod_name"),
                        rs.getInt("stock"),
                        rs.getDouble("price")
                );
            }
        } catch (SQLException ex) {
            System.out.println("Error in getProductByName: " + ex.getMessage());
        }
        return product;
    }
}
