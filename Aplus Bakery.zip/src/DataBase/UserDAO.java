package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.User;

public class UserDAO {

    private final Connection con;

     public UserDAO() {
        con = DbConnection.getConnection();
        if (con == null) {
            throw new RuntimeException("Database connection failed. Please check your connection settings.");
        }
    }
    
    

    // Create a new user
    public void createUser(User user) {
        String query = "INSERT INTO user (User_id, username, pass, role) VALUES (?, ?, ?, ?)";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, user.getUserId());
            stmt.setString(2, user.getUsername());
            stmt.setString(3, user.getPassword());
            stmt.setString(4, user.getRole());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in createUser: " + ex.getMessage());
        }
    }

    // Retrieve a user by ID
    public User getUser(int userId) {
        User user = null;
        String query = "SELECT * FROM user WHERE User_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                user = new User(
                        rs.getInt("User_id"),
                        rs.getString("username"),
                        rs.getString("pass"),
                        rs.getString("role") // Retrieve role
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error in getUser: " + ex.getMessage());
        }
        return user;
    }

    // Retrieve all users
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM user";
        try ( Statement stmt = con.createStatement();  ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                User user = new User(
                        rs.getInt("User_id"),
                        rs.getString("username"),
                        rs.getString("pass"),
                        rs.getString("role") // Get role
                );
                users.add(user);
            }
        } catch (SQLException ex) {
            System.err.println("Error in getAllUsers: " + ex.getMessage());
        }
        return users;
    }

    // Update a user
    public void updateUser(User user) {
        String query = "UPDATE user SET username = ?, pass = ?, role = ? WHERE User_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getRole());
            stmt.setInt(4, user.getUserId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in updateUser: " + ex.getMessage());
        }
    }

    // Delete a user
    public void deleteUser(int userId) {
        String query = "DELETE FROM user WHERE User_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, userId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in deleteUser: " + ex.getMessage());
        }
    }
    
    // Method to get a user by username and password
    public User getUserByUsernameAndPassword(String username, String password) {
        User user = null;
        if (con == null) {
            throw new RuntimeException("No database connection.");
        }

        String query = "SELECT * FROM user WHERE username = ? AND pass = ?";
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                user = new User(
                    rs.getInt("User_id"),
                    rs.getString("username"),
                    rs.getString("pass"),
                    rs.getString("role")
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error in getUserByUsernameAndPassword: " + ex.getMessage());
        }

        return user;
    }
}
