package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Employee;

public class EmployeeDAO {

    private Connection con;

    public EmployeeDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new employee
    public void createEmployee(Employee employee) {
        try {
            String query = "INSERT INTO employee (Emp_id, Sex, Fname, Lname, Mng_id, MStartDate, age, gender, password, username, phone, workinghours, salary) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, employee.getEmployeeId());
            stmt.setString(2, Character.toString(employee.getSex()));
            stmt.setString(3, employee.getFirstName());
            stmt.setString(4, employee.getLastName());
            stmt.setObject(5, employee.getManagerId());
            stmt.setString(6, employee.getManagementStartDate());
            stmt.setInt(7, employee.getAge());  // New field
            stmt.setString(8, employee.getGender()); // New field
            stmt.setString(9, employee.getPassword()); // New field
            stmt.setString(10, employee.getUsername()); // New field
            stmt.setString(11, employee.getPhone()); // New field
            stmt.setInt(12, employee.getWorkingHours()); // New field
            stmt.setDouble(13, employee.getSalary()); // New field
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in createEmployee: " + ex.getMessage());
        }
    }

    // Retrieve an employee by ID
    public Employee getEmployee(int employeeId) {
        Employee employee = null;
        try {
            String query = "SELECT * FROM employee WHERE Emp_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, employeeId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                employee = new Employee(
                        rs.getInt("Emp_id"),
                        rs.getString("Sex").charAt(0),
                        rs.getString("Fname"),
                        rs.getString("Lname"),
                        rs.getObject("Mng_id", Integer.class),
                        rs.getString("MStartDate"),
                        null,
                        rs.getInt("age"), // New field
                        rs.getString("gender"), // New field
                        rs.getString("password"), // New field
                        rs.getString("username"), // New field
                        rs.getString("phone"), // New field
                        rs.getInt("workinghours"), // New field
                        rs.getDouble("salary") // New field
                );
            }
        } catch (SQLException ex) {
            System.out.println("Error in getEmployee: " + ex.getMessage());
        }
        return employee;
    }

    // Retrieve all employees
    public List<Employee> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        try {
            String query = "SELECT * FROM employee";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                Employee employee = new Employee(
                        rs.getInt("Emp_id"),
                        rs.getString("Sex").charAt(0),
                        rs.getString("Fname"),
                        rs.getString("Lname"),
                        rs.getObject("Mng_id", Integer.class),
                        rs.getString("MStartDate"),
                        null,
                        rs.getInt("age"), // New field
                        rs.getString("gender"), // New field
                        rs.getString("password"), // New field
                        rs.getString("username"), // New field
                        rs.getString("phone"), // New field
                        rs.getInt("workinghours"), // New field
                        rs.getDouble("salary") // New field
                );
                employees.add(employee);
            }
        } catch (SQLException ex) {
            System.out.println("Error in getAllEmployees: " + ex.getMessage());
        }
        return employees;
    }

    // Update an employee
    public void updateEmployee(Employee employee) {
        try {
            String query = "UPDATE employee SET Sex = ?, Fname = ?, Lname = ?, Mng_id = ?, MStartDate = ?, age = ?, gender = ?, password = ?, username = ?, phone = ?, workinghours = ?, salary = ? WHERE Emp_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, Character.toString(employee.getSex()));
            stmt.setString(2, employee.getFirstName());
            stmt.setString(3, employee.getLastName());
            stmt.setObject(4, employee.getManagerId());
            stmt.setString(5, employee.getManagementStartDate());
            stmt.setInt(6, employee.getAge()); // New field
            stmt.setString(7, employee.getGender()); // New field
            stmt.setString(8, employee.getPassword()); // New field
            stmt.setString(9, employee.getUsername()); // New field
            stmt.setString(10, employee.getPhone()); // New field
            stmt.setInt(11, employee.getWorkingHours()); // New field
            stmt.setDouble(12, employee.getSalary()); // New field
            stmt.setInt(13, employee.getEmployeeId()); // Where condition
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in updateEmployee: " + ex.getMessage());
        }
    }

    // Delete an employee
    public void deleteEmployee(int employeeId) {
        try {
            String query = "DELETE FROM employee WHERE Emp_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, employeeId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in deleteEmployee: " + ex.getMessage());
        }
    }

}
