package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.CreditCard;

public class CreditCardDAO {

    private Connection con;

    public CreditCardDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new credit card record
    public void createCreditCard(CreditCard creditCard) {
        String query = "INSERT INTO credit_card (Card_id, card_num, exp_date, card_name) VALUES (?, ?, ?, ?)";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, creditCard.getCardId());
            stmt.setString(2, creditCard.getCardNum());
            stmt.setString(3, creditCard.getExpDate());
            stmt.setString(4, creditCard.getCardName());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in createCreditCard: " + ex.getMessage());
        }
    }

    // Retrieve a credit card record by ID
    public CreditCard getCreditCard(int cardId) {
        CreditCard creditCard = null;
        String query = "SELECT * FROM credit_card WHERE Card_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, cardId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                creditCard = new CreditCard(
                        rs.getInt("Card_id"),
                        rs.getString("card_num"),
                        rs.getString("exp_date"),
                        rs.getString("card_name"),
                        null
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error in getCreditCard: " + ex.getMessage());
        }
        return creditCard;
    }

    // Retrieve all credit card records
    public List<CreditCard> getAllCreditCards() {
        List<CreditCard> creditCards = new ArrayList<>();
        String query = "SELECT * FROM credit_card";
        try ( Statement stmt = con.createStatement();  ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                CreditCard creditCard = new CreditCard(
                        rs.getInt("Card_id"),
                        rs.getString("card_num"),
                        rs.getString("exp_date"),
                        rs.getString("card_name"),
                        null
                );
                creditCards.add(creditCard);
            }
        } catch (SQLException ex) {
            System.err.println("Error in getAllCreditCards: " + ex.getMessage());
        }
        return creditCards;
    }

    // Update a credit card record
    public void updateCreditCard(CreditCard creditCard) {
        String query = "UPDATE credit_card SET card_num = ?, exp_date = ?, card_name = ? WHERE Card_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, creditCard.getCardNum());
            stmt.setString(2, creditCard.getExpDate());
            stmt.setString(3, creditCard.getCardName());
            stmt.setInt(4, creditCard.getCardId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in updateCreditCard: " + ex.getMessage());
        }
    }

    // Delete a credit card record
    public void deleteCreditCard(int cardId) {
        String query = "DELETE FROM credit_card WHERE Card_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, cardId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in deleteCreditCard: " + ex.getMessage());
        }
    }
}
