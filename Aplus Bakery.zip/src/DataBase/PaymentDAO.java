package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Payment;
public class PaymentDAO {

    private final Connection con;

    public PaymentDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new payment record
    public void createPayment(Payment payment) {
        String query = "INSERT INTO payment (Pay_id, pay_amount, Order_id) VALUES (?, ?, ?)";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, payment.getPaymentId());
            stmt.setDouble(2, payment.getPayAmount());
            stmt.setObject(3, payment.getOrderId(), Types.INTEGER);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in createPayment: " + ex.getMessage());
        }
    }

    // Retrieve a payment record by ID
    public Payment getPayment(int paymentId) {
        Payment payment = null;
        String query = "SELECT * FROM payment WHERE Pay_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, paymentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                payment = new Payment(
                        rs.getInt("Pay_id"),
                        rs.getDouble("pay_amount"),
                        rs.getObject("Order_id", Integer.class),
                        null // Cart reference (can be resolved separately)
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error in getPayment: " + ex.getMessage());
        }
        return payment;
    }

    // Retrieve all payment records
    public List<Payment> getAllPayments() {
        List<Payment> payments = new ArrayList<>();
        String query = "SELECT * FROM payment";
        try ( Statement stmt = con.createStatement();  ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Payment payment = new Payment(
                        rs.getInt("Pay_id"),
                        rs.getDouble("pay_amount"),
                        rs.getObject("Order_id", Integer.class),
                        null // Cart reference
                );
                payments.add(payment);
            }
        } catch (SQLException ex) {
            System.err.println("Error in getAllPayments: " + ex.getMessage());
        }
        return payments;
    }

    // Update a payment record
    public void updatePayment(Payment payment) {
        String query = "UPDATE payment SET pay_amount = ?, Order_id = ? WHERE Pay_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setDouble(1, payment.getPayAmount());
            stmt.setObject(2, payment.getOrderId(), Types.INTEGER);
            stmt.setInt(3, payment.getPaymentId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in updatePayment: " + ex.getMessage());
        }
    }

    // Delete a payment record
    public void deletePayment(int paymentId) {
        String query = "DELETE FROM payment WHERE Pay_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, paymentId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in deletePayment: " + ex.getMessage());
        }
    }
    
    // Retrieve the payment amount for a specific order
    public double getPaymentAmount(int orderId) {
        double paymentAmount = 0.0;
        String query = "SELECT pay_amount FROM payment WHERE Order_id = ?";

        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                paymentAmount = rs.getDouble("pay_amount"); // Fetch the payment amount
            }
        } catch (SQLException ex) {
            System.err.println("Error in getPaymentAmount: " + ex.getMessage());
        }

        return paymentAmount; // Return the payment amount for the given order
    }
}
