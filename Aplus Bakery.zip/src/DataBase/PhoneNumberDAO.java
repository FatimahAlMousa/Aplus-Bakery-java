package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.PhoneNumber;

public class PhoneNumberDAO {

    private final Connection con;

    public PhoneNumberDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new phone number record
    public void createPhoneNumber(PhoneNumber phoneNumber) {
        String query = "INSERT INTO phonenumber (Phone, cust_id) VALUES (?, ?)";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, phoneNumber.getPhone());
            stmt.setInt(2, phoneNumber.getCustomerId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in createPhoneNumber: " + ex.getMessage());
        }
    }

    // Retrieve a phone number record by phone
    public PhoneNumber getPhoneNumber(String phone) {
        PhoneNumber phoneNumber = null;
        String query = "SELECT * FROM phonenumber WHERE Phone = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, phone);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                phoneNumber = new PhoneNumber(
                        rs.getString("Phone"),
                        rs.getInt("cust_id"),
                        null // Reference to Customer (optional)
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error in getPhoneNumber: " + ex.getMessage());
        }
        return phoneNumber;
    }

    // Retrieve all phone number records
    public List<PhoneNumber> getAllPhoneNumbers() {
        List<PhoneNumber> phoneNumberList = new ArrayList<>();
        String query = "SELECT * FROM phonenumber";
        try ( Statement stmt = con.createStatement();  ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                PhoneNumber phoneNumber = new PhoneNumber(
                        rs.getString("Phone"),
                        rs.getInt("cust_id"),
                        null // Reference to Customer (optional)
                );
                phoneNumberList.add(phoneNumber);
            }
        } catch (SQLException ex) {
            System.err.println("Error in getAllPhoneNumbers: " + ex.getMessage());
        }
        return phoneNumberList;
    }

    // Update a phone number record
    public void updatePhoneNumber(PhoneNumber phoneNumber) {
        String query = "UPDATE phonenumber SET Phone = ? WHERE Phone = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, phoneNumber.getPhone());
            stmt.setString(2, phoneNumber.getPhone());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in updatePhoneNumber: " + ex.getMessage());
        }
    }

    // Delete a phone number record
    public void deletePhoneNumber(String phone) {
        String query = "DELETE FROM phonenumber WHERE Phone = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, phone);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in deletePhoneNumber: " + ex.getMessage());
        }
    }
}
