package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Oversees;

public class OverseesDAO {

    private final Connection con;

    public OverseesDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new oversee record
    public void createOversees(Oversees oversees) {
        String query = "INSERT INTO oversees (emp_o_id, order_o_id) VALUES (?, ?)";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, oversees.getEmployeeId());
            stmt.setInt(2, oversees.getOrderId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in createOversees: " + ex.getMessage());
        }
    }

    // Retrieve an oversee record by employee ID and order ID
    public Oversees getOversees(int employeeId, int orderId) {
        Oversees oversees = null;
        String query = "SELECT * FROM oversees WHERE emp_o_id = ? AND order_o_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            stmt.setInt(2, orderId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                oversees = new Oversees(
                        rs.getInt("emp_o_id"),
                        rs.getInt("order_o_id"),
                        null, // Employee reference
                        null // Cart reference
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error in getOversees: " + ex.getMessage());
        }
        return oversees;
    }

    // Retrieve all oversee records
    public List<Oversees> getAllOversees() {
        List<Oversees> overseesList = new ArrayList<>();
        String query = "SELECT * FROM oversees";
        try ( Statement stmt = con.createStatement();  ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Oversees oversees = new Oversees(
                        rs.getInt("emp_o_id"),
                        rs.getInt("order_o_id"),
                        null, // Employee reference
                        null // Cart reference
                );
                overseesList.add(oversees);
            }
        } catch (SQLException ex) {
            System.err.println("Error in getAllOversees: " + ex.getMessage());
        }
        return overseesList;
    }

    // Update an oversee record
    public void updateOversees(Oversees oversees) {
        String query = "UPDATE oversees SET emp_o_id = ?, order_o_id = ? WHERE emp_o_id = ? AND order_o_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, oversees.getEmployeeId());
            stmt.setInt(2, oversees.getOrderId());
            stmt.setInt(3, oversees.getEmployeeId());
            stmt.setInt(4, oversees.getOrderId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in updateOversees: " + ex.getMessage());
        }
    }

    // Delete an oversee record
    public void deleteOversees(int employeeId, int orderId) {
        String query = "DELETE FROM oversees WHERE emp_o_id = ? AND order_o_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            stmt.setInt(2, orderId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in deleteOversees: " + ex.getMessage());
        }
    }
}
