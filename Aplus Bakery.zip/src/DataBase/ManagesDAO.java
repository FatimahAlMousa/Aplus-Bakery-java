package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Manages;

public class ManagesDAO {

    private final Connection con;

    public ManagesDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new management record
    public void createManages(Manages manages) {
        String query = "INSERT INTO manages (emp_id, prod_id) VALUES (?, ?)";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, manages.getEmployeeId());
            stmt.setInt(2, manages.getProductId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in createManages: " + ex.getMessage());
        }
    }

    // Retrieve a management record by employee ID and product ID
    public Manages getManages(int employeeId, int productId) {
        String query = "SELECT * FROM manages WHERE emp_id = ? AND prod_id = ?";
        Manages manages = null;
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            stmt.setInt(2, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                manages = new Manages(
                        rs.getInt("emp_id"),
                        rs.getInt("prod_id"),
                        null, // Employee reference
                        null // Product reference
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error in getManages: " + ex.getMessage());
        }
        return manages;
    }

    // Get all manages with additional information (Employee name, Product name)
    public List<Manages> getAllManages() {
        List<Manages> managesList = new ArrayList<>();
        String query = "SELECT m.emp_id, m.prod_id, e.Fname AS employee_firstname, "
                + "e.Lname AS employee_lastname, p.Prod_name AS product_name "
                + "FROM manages m "
                + "INNER JOIN employee e ON m.emp_id = e.Emp_id "
                + "INNER JOIN product p ON m.prod_id = p.Prod_id";
        try ( Statement stmt = con.createStatement();  ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Manages manages = new Manages(
                        rs.getInt("emp_id"),
                        rs.getInt("prod_id"),
                        null, // Employee reference
                        null // Product reference
                );
                manages.setEmployeeFirstName(rs.getString("employee_firstname"));
                manages.setEmployeeLastName(rs.getString("employee_lastname"));
                manages.setProductName(rs.getString("product_name"));

                managesList.add(manages);
            }
        } catch (SQLException ex) {
            System.err.println("Error in getAllManages: " + ex.getMessage());
        }
        return managesList;
    }

    // Update a management record
    public void updateManages(Manages manages) {
        String query = "UPDATE manages SET emp_id = ?, prod_id = ? WHERE emp_id = ? AND prod_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, manages.getEmployeeId());
            stmt.setInt(2, manages.getProductId());
            stmt.setInt(3, manages.getEmployeeId());
            stmt.setInt(4, manages.getProductId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in updateManages: " + ex.getMessage());
        }
    }

    // Delete a management record
    public void deleteManages(int employeeId, int productId) {
        String query = "DELETE FROM manages WHERE emp_id = ? AND prod_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            stmt.setInt(2, productId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in deleteManages: " + ex.getMessage());
        }
    }
}
