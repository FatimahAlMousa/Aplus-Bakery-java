package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Cart;

public class CartDAO {

    private final Connection con;

    public CartDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new cart
    public void createCart(Cart cart) {
        String query = "INSERT INTO cart (order_id, cust_id_has, payment_id) VALUES (?, ?, ?)";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, cart.getOrderId());
            stmt.setObject(2, cart.getCustomerId());
            stmt.setObject(3, cart.getPaymentId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in createCart: " + ex.getMessage());
        }
    }

    // Retrieve a cart by ID
    public Cart getCart(int orderId) {
        Cart cart = null;
        String query = "SELECT * FROM cart WHERE order_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                cart = new Cart(
                        rs.getInt("order_id"),
                        rs.getObject("cust_id_has", Integer.class),
                        rs.getObject("payment_id", Integer.class),
                        null, // You would need additional logic to load the Customer and Payment
                        null
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error in getCart: " + ex.getMessage());
        }
        return cart;
    }

    // Retrieve all carts
    public List<Cart> getAllCarts() {
        List<Cart> carts = new ArrayList<>();
        String query = "SELECT * FROM cart";
        try ( Statement stmt = con.createStatement();  ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Cart cart = new Cart(
                        rs.getInt("order_id"),
                        rs.getObject("cust_id_has", Integer.class),
                        rs.getObject("payment_id", Integer.class),
                        null,
                        null
                );
                carts.add(cart);
            }
        } catch (SQLException ex) {
            System.err.println("Error in getAllCarts: " + ex.getMessage());
        }
        return carts;
    }

    // Update a cart
    public void updateCart(Cart cart) {
        String query = "UPDATE cart SET cust_id_has = ?, payment_id = ? WHERE order_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setObject(1, cart.getCustomerId());
            stmt.setObject(2, cart.getPaymentId());
            stmt.setInt(3, cart.getOrderId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in updateCart: " + ex.getMessage());
        }
    }

    // Delete a cart
    public void deleteCart(int orderId) {
        String query = "DELETE FROM cart WHERE order_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, orderId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in deleteCart: " + ex.getMessage());
        }
    }

    // Retrieve carts by customer ID
   public double calculateTotalAmount(int orderId) {
    double total = 0.0;
    // Ensure the correct structure: Join 'contain' with 'product' to get the price and possibly 'quantity' if it exists
    String query = "SELECT p.price FROM contain c " +
                   "JOIN product p ON c.prod_id = p.Prod_id " +
                   "WHERE c.order_id = ?";

    try (PreparedStatement stmt = con.prepareStatement(query)) {
        stmt.setInt(1, orderId);
        ResultSet rs = stmt.executeQuery();

        // If 'quantity' is missing, consider quantity as 1 or a default value
        while (rs.next()) {
            double price = rs.getDouble("price");
            int quantity = 1; // Default quantity if 'quantity' column is missing
            total += price * quantity; // Calculate total cost based on price
        }
    } catch (SQLException ex) {
        System.err.println("Error in calculateTotalAmount: " + ex.getMessage());
    }

    return total; // Return the calculated total cost for the cart/order
}


// Get the number of items in a cart
 public int getNumberOfItems(int orderId) {
    int totalItems = 0;
    // Count unique products in the 'contain' table linked to an order
    String query = "SELECT COUNT(c.prod_id) AS total_items FROM contain c WHERE c.order_id = ?"; 

    try (PreparedStatement stmt = con.prepareStatement(query)) {
        stmt.setInt(1, orderId);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            totalItems = rs.getInt("total_items"); // Get the total count of products
        }
    } catch (SQLException ex) {
        System.err.println("Error in getNumberOfItems: " + ex.getMessage());
    }

    return totalItems; // Return the total count of unique items in the cart/order
}



    // In CartDAO class
    public List<Cart> getCartsByCustomerId(int customerId) {
        List<Cart> carts = new ArrayList<>();
        String query = "SELECT * FROM cart WHERE cust_id_has = ?"; // Adjust table name and field name if needed

        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Cart cart = new Cart(
                        rs.getInt("order_id"), // Order ID
                        rs.getObject("cust_id_has", Integer.class), // Customer ID
                        null // Other fields as needed
                );
                carts.add(cart);
            }
        } catch (SQLException ex) {
            System.err.println("Error in getCartsByCustomerId: " + ex.getMessage());
        }

        return carts;
    }

}
