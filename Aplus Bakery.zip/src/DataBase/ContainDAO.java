package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Contain;

public class ContainDAO {

    private Connection con;

    public ContainDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new contain record
    public void createContain(Contain contain) {
        String query = "INSERT INTO contain (order_id, prod_id) VALUES (?, ?)";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, contain.getOrderId());
            stmt.setInt(2, contain.getProductId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in createContain: " + ex.getMessage());
        }
    }

    // Retrieve a contain record by order ID and product ID
    public Contain getContain(int orderId, int productId) {
        String query = "SELECT * FROM contain WHERE order_id = ? AND prod_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, orderId);
            stmt.setInt(2, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Contain(
                        rs.getInt("order_id"),
                        rs.getInt("prod_id"),
                        null,
                        null
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error in getContain: " + ex.getMessage());
        }
        return null;
    }

    // Retrieve all contain records
    public List<Contain> getAllContains() {
        List<Contain> containList = new ArrayList<>();
        String query = "SELECT * FROM contain";
        try ( Statement stmt = con.createStatement();  ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Contain contain = new Contain(
                        rs.getInt("order_id"),
                        rs.getInt("prod_id"),
                        null,
                        null
                );
                containList.add(contain);
            }
        } catch (SQLException ex) {
            System.err.println("Error in getAllContains: " + ex.getMessage());
        }
        return containList;
    }

    // Update a contain record
    public void updateContain(Contain contain) {
        String query = "UPDATE contain SET order_id = ?, prod_id = ? WHERE order_id = ? AND prod_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, contain.getOrderId());
            stmt.setInt(2, contain.getProductId());
            stmt.setInt(3, contain.getOrderId());
            stmt.setInt(4, contain.getProductId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in updateContain: " + ex.getMessage());
        }
    }

    // Delete a contain record
    public void deleteContain(int orderId, int productId) {
        String query = "DELETE FROM contain WHERE order_id = ? AND prod_id = ?";
        try ( PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, orderId);
            stmt.setInt(2, productId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.err.println("Error in deleteContain: " + ex.getMessage());
        }
    }
}
