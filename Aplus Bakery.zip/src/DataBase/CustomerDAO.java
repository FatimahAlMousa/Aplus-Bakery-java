package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Customer;
import static gui.Login.CusId;
public class CustomerDAO {
    private Connection con;

    public CustomerDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new customer
public void createCustomer(Customer customer) {
    try {
        String query = "INSERT INTO customer (cust_id, FName, LName, Cust_address, password, email, phoneNo, gender, username) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement stmt = con.prepareStatement(query);
        stmt.setInt(1, customer.getCustomerId());
        stmt.setString(2, customer.getFirstName());
        stmt.setString(3, customer.getLastName());
        stmt.setString(4, customer.getAddress());
        stmt.setString(5, customer.getPassword());
        stmt.setString(6, customer.getEmail());
        stmt.setString(7, customer.getPhoneNo());
        stmt.setString(8, customer.getGender());
        stmt.setString(9, customer.getUsername()); // Set the new "username" field
        stmt.executeUpdate();
    } catch (SQLException ex) {
        System.out.println("Error in createCustomer: " + ex.getMessage());
    }
}



    // Retrieve a customer by ID
 public Customer getCustomer(int customerId) {
    Customer customer = null;
    try {
        String query = "SELECT * FROM customer WHERE cust_id = ?";
        PreparedStatement stmt = con.prepareStatement(query);
        stmt.setInt(1, customerId);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            customer = new Customer(
                rs.getInt("cust_id"),
                rs.getString("FName"),
                rs.getString("LName"),
                rs.getString("Cust_address"),
                null,
                rs.getString("password"),
                rs.getString("email"),
                rs.getString("phoneNo"),
                rs.getString("gender"),
                rs.getString("username") // Retrieve the new "username"
            );
        }
    } catch (SQLException ex) {
        System.out.println("Error in getCustomer: " + ex.getMessage());
    }
    return customer;
}


    // Retrieve all customers
  public List<Customer> getAllCustomers() {
    List<Customer> customers = new ArrayList<>();
    try {
        String query = "SELECT * FROM customer";
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        while (rs.next()) {
            Customer customer = new Customer(
                rs.getInt("cust_id"),
                rs.getString("FName"),
                rs.getString("LName"),
                rs.getString("Cust_address"),
                null,
                rs.getString("password"),
                rs.getString("email"),
                rs.getString("phoneNo"),
                rs.getString("gender"),
                rs.getString("username") // Include the new "username" field
            );
            customers.add(customer);
        }
    } catch (SQLException ex) {
        System.out.println("Error in getAllCustomers: " + ex.getMessage());
    }
    return customers;
}



    // Update a customer
public void updateCustomer(Customer customer) {
    try {
        String query = "UPDATE customer SET FName = ?, LName = ?, Cust_address = ?, password = ?, email = ?, phoneNo = ?, gender = ?, username = ? WHERE cust_id = ?";
        PreparedStatement stmt = con.prepareStatement(query);
        stmt.setString(1, customer.getFirstName());
        stmt.setString(2, customer.getLastName());
        stmt.setString(3, customer.getAddress());
        stmt.setString(4, customer.getPassword());
        stmt.setString(5, customer.getEmail());
        stmt.setString(6, customer.getPhoneNo());
        stmt.setString(7, customer.getGender());
        stmt.setString(8, customer.getUsername());
        stmt.setInt(9, customer.getCustomerId());
        stmt.executeUpdate();
    } catch (SQLException ex) {
        System.out.println("Error in updateCustomer: " + ex.getMessage());
    }
}


    // Delete a customer
    public void deleteCustomer(int customerId) {
        try {
            String query = "DELETE FROM customer WHERE cust_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, customerId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in deleteCustomer: " + ex.getMessage());
        }
    }
    
    // Retrieve a customer by username and password
    public Customer getCustomerByUsernameAndPassword(String username, String password) {
        Customer customer = null;
        try {
            // SQL query to select a customer by username and password
            String query = "SELECT * FROM customer WHERE username = ? AND password = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, username);  // Set the username parameter
            stmt.setString(2, password);  // Set the password parameter
            ResultSet rs = stmt.executeQuery();

            // If a result is found, create a Customer object with the retrieved data
            if (rs.next()) {
               CusId= rs.getString("cust_id");
                customer = new Customer(
                    rs.getInt("cust_id"),  // Customer ID
                    rs.getString("FName"),  // First name
                    rs.getString("LName"),  // Last name
                    rs.getString("Cust_address"),  // Address
                    rs.getString("password"),  // Password
                    rs.getString("email"),  // Email
                    rs.getString("phoneNo"),  // Phone number
                    rs.getString("gender"),  // Gender
                    rs.getString("username")  // Username
                );
            }
        } catch (SQLException ex) {
            System.err.println("Error in getCustomerByUsernameAndPassword: " + ex.getMessage());
        }

        return customer;  // Return the found customer or null if no match
    }

}
