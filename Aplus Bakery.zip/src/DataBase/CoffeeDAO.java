package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Coffee;

public class CoffeeDAO {

    private Connection con;

    public CoffeeDAO() {
        con = DbConnection.getConnection();
    }

    // Create a new coffee
    public void createCoffee(Coffee coffee) {
        try {
            String query = "INSERT INTO coffee (Prod_id, CoffeeType, CoffeeSize) VALUES (?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, coffee.getProductId());
            stmt.setString(2, coffee.getCoffeeType());
            stmt.setString(3, coffee.getCoffeeSize());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in createCoffee: " + ex.getMessage());
        }
    }

    // Retrieve a coffee by ID
    public Coffee getCoffee(int productId) {
        Coffee coffee = null;
        try {
            String query = "SELECT * FROM coffee WHERE Prod_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                coffee = new Coffee(rs.getInt("Prod_id"), rs.getString("CoffeeType"), rs.getString("CoffeeSize"), null);
            }
        } catch (SQLException ex) {
            System.out.println("Error in getCoffee: " + ex.getMessage());
        }
        return coffee;
    }

    // Retrieve all coffees
    public List<Coffee> getAllCoffees() {
        List<Coffee> coffees = new ArrayList<>();
        try {
            String query = "SELECT * FROM coffee";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                Coffee coffee = new Coffee(rs.getInt("Prod_id"), rs.getString("CoffeeType"), rs.getString("CoffeeSize"), null);
                coffees.add(coffee);
            }
        } catch (SQLException ex) {
            System.out.println("Error in getAllCoffees: " + ex.getMessage());
        }
        return coffees;
    }

    // Update a coffee
    public void updateCoffee(Coffee coffee) {
        try {
            String query = "UPDATE coffee SET CoffeeType = ?, CoffeeSize = ? WHERE Prod_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, coffee.getCoffeeType());
            stmt.setString(2, coffee.getCoffeeSize());
            stmt.setInt(3, coffee.getProductId());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in updateCoffee: " + ex.getMessage());
        }
    }

    // Delete a coffee
    public void deleteCoffee(int productId) {
        try {
            String query = "DELETE FROM coffee WHERE Prod_id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, productId);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error in deleteCoffee: " + ex.getMessage());
        }
    }
}
