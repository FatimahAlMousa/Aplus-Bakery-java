package DataBase;

import java.sql.*;

public class DbConnection {
    private static Connection con;

    public static Connection getConnection() {
        if (con == null) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                String url = "jdbc:mysql://localhost:3306/company";
                String user = "root";
                String password = "M1o3s8a8";

                con = DriverManager.getConnection(url, user, password);
                System.out.println("Connected to database.");
            } catch (ClassNotFoundException ex) {
                System.err.println("JDBC driver not found: " + ex.getMessage());
            } catch (SQLException ex) {
                System.err.println("Error connecting to database: " + ex.getMessage());
            }
        }
        return con;
    }
}
