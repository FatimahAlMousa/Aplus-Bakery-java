package model;

public class Coffee {

    private int productId;
    private String coffeeType;
    private String coffeeSize;
    private Product product; // Reference to Product

    public Coffee(int productId, String coffeeType, String coffeeSize, Product product) {
        this.productId = productId;
        this.coffeeType = coffeeType;
        this.coffeeSize = coffeeSize;
        this.product = product;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getCoffeeType() {
        return coffeeType;
    }

    public void setCoffeeType(String coffeeType) {
        this.coffeeType = coffeeType;
    }

    public String getCoffeeSize() {
        return coffeeSize;
    }

    public void setCoffeeSize(String coffeeSize) {
        this.coffeeSize = coffeeSize;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}
