 
package model;

public class Oversees {

    private int employeeId;
    private int orderId;
    private Employee employee; // Reference to Employee
    private Cart cart; // Reference to Cart

    public Oversees(int employeeId, int orderId, Employee employee, Cart cart) {
        this.employeeId = employeeId;
        this.orderId = orderId;
        this.employee = employee;
        this.cart = cart;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }
}
