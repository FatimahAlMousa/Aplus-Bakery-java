 
package model;

public class   CreditCard {
    private int cardId;
    private String cardNum;
    private String expDate;
    private String cardName;
    private Payment payment; // Reference to Payment

    public CreditCard() {
    }

    public CreditCard(String cardNum, String expDate, String cardName, Payment payment) {
        this.cardNum = cardNum;
        this.expDate = expDate;
        this.cardName = cardName;
        this.payment = payment;
    }
    

    public CreditCard(int cardId, String cardNum, String expDate, String cardName, Payment payment) {
        this.cardId = cardId;
        this.cardNum = cardNum;
        this.expDate = expDate;
        this.cardName = cardName;
        this.payment = payment;
    }

 

    public int getCardId() {
        return cardId;
    }

    public void setCardId(int cardId) {
        this.cardId = cardId;
    }

    public String getCardNum() {
        return cardNum;
    }

    public void setCardNum(String cardNum) {
        this.cardNum = cardNum;
    }

    public String getExpDate() {
        return expDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    public String getCardName() {
        return cardName;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }
}

