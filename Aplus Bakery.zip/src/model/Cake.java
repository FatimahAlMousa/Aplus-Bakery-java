package model;

public class Cake {

    private int cakeId;
    private String cakeType;
    private Product product; // Reference to the Product class

    public Cake(int cakeId, String cakeType, Product product) {
        this.cakeId = cakeId;
        this.cakeType = cakeType;
        this.product = product;
    }

    public int getCakeId() {
        return cakeId;
    }

    public void setCakeId(int cakeId) {
        this.cakeId = cakeId;
    }

    public String getCakeType() {
        return cakeType;
    }

    public void setCakeType(String cakeType) {
        this.cakeType = cakeType;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}
