package model;

public class Customer {

    private int customerId;
    private String firstName;
    private String lastName;
    private String address;
    private User user;
    private String password; // Existing field
    private String email;    // Existing field
    private String phoneNo;  // Existing field
    private String gender;   // Existing field
    private String username; // New field

    public Customer(int customerId, String firstName, String lastName, String address, User user,
            String password, String email, String phoneNo, String gender, String username) { // Updated constructor
        this.customerId = customerId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.user = user;
        this.password = password;
        this.email = email;
        this.phoneNo = phoneNo;
        this.gender = gender;
        this.username = username; // Initialize new field
    }

    public Customer(int customerId, String firstName, String lastName, String address, String password, String email, String phoneNo, String gender, String username) {
        this.customerId = customerId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.password = password;
        this.email = email;
        this.phoneNo = phoneNo;
        this.gender = gender;
        this.username = username;
    }

    public Customer(String firstName, String lastName, String address, String password, String email, String phoneNo, String gender, String username) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.password = password;
        this.email = email;
        this.phoneNo = phoneNo;
        this.gender = gender;
        this.username = username;
    }

    // Getters and Setters for all fields, including new "username" field
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

}
