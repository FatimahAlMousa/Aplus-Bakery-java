package model;

public class Payment {

    private int paymentId;
    private double payAmount;
    private Integer orderId;
    private Cart cart; // Reference to Cart

    public Payment(int paymentId, double payAmount, Integer orderId, Cart cart) {
        this.paymentId = paymentId;
        this.payAmount = payAmount;
        this.orderId = orderId;
        this.cart = cart;
    }

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public double getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(double payAmount) {
        this.payAmount = payAmount;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }
}
