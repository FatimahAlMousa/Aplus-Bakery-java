package model;

public class Employee {

    private int employeeId;
    private char sex;
    private String firstName;
    private String lastName;
    private Integer managerId;
    private String managementStartDate;
    private User user;
    private int age;              // New field
    private String gender;        // New field
    private String password;      // New field
    private String username;      // New field
    private String phone;         // New field
    private int workingHours;     // New field
    private double salary;        // New field

    public Employee(char sex, String firstName, String lastName, Integer managerId, String managementStartDate, int age, String gender, String password, String username, String phone, int workingHours, double salary) {
        this.sex = sex;
        this.firstName = firstName;
        this.lastName = lastName;
        this.managerId = managerId;
        this.managementStartDate = managementStartDate;
        this.age = age;
        this.gender = gender;
        this.password = password;
        this.username = username;
        this.phone = phone;
        this.workingHours = workingHours;
        this.salary = salary;
    }

    
    
    public Employee(int employeeId, char sex, String firstName, String lastName, Integer managerId, 
                    String managementStartDate, User user, int age, String gender, String password,
                    String username, String phone, int workingHours, double salary) {
        this.employeeId = employeeId;
        this.sex = sex;
        this.firstName = firstName;
        this.lastName = lastName;
        this.managerId = managerId;
        this.managementStartDate = managementStartDate;
        this.user = user;
        this.age = age;
        this.gender = gender;
        this.password = password;
        this.username = username;
        this.phone = phone;
        this.workingHours = workingHours;
        this.salary = salary;
    }

    // Getters and Setters for new fields
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getWorkingHours() {
        return workingHours;
    }

    public void setWorkingHours(int workingHours) {
        this.workingHours = workingHours;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getManagerId() {
        return managerId;
    }

    public void setManagerId(Integer managerId) {
        this.managerId = managerId;
    }

    public String getManagementStartDate() {
        return managementStartDate;
    }

    public void setManagementStartDate(String managementStartDate) {
        this.managementStartDate = managementStartDate;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

   
}
