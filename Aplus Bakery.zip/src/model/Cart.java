package model;

import java.util.List;

public class Cart {

    private int orderId;
    private Integer customerId;
    private Integer paymentId;
    private Customer customer; // Reference to Customer
    private Payment payment; // Reference to Payment
    
     private List<Product> products; // Cart items
    private double totalAmount; // Total cost of the cart

    public Cart(int orderId, Integer customerId, Integer paymentId, Customer customer, Payment payment) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.paymentId = paymentId;
        this.customer = customer;
        this.payment = payment;
    }
    
     // Constructor for creating a Cart with essential information
    public Cart(int orderId, int customerId, List<Product> products) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.products = products;
        this.totalAmount = calculateTotalAmount(); // Calculate the total cost when creating the cart
    }
// Calculate the total cost for the cart
    private double calculateTotalAmount() {
        double total = 0;
        if (products != null) {
            for (Product product : products) {
                total += product.getPrice() * product.getStock(); // Price times quantity
            }
        }
        return total;
    }
    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public Integer getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Integer paymentId) {
        this.paymentId = paymentId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }
}
