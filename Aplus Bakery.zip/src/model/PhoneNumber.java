package model;

public class PhoneNumber {

    private String phone;
    private int customerId;
    private Customer customer; // Reference to Customer

    public PhoneNumber(String phone, int customerId, Customer customer) {
        this.phone = phone;
        this.customerId = customerId;
        this.customer = customer;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
