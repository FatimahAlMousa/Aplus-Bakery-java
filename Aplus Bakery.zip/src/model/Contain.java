package model;

public class Contain {

    private int orderId;
    private int productId;
    private Cart cart; // Reference to Cart
    private Product product; // Reference to Product

    public Contain(int orderId, int productId, Cart cart, Product product) {
        this.orderId = orderId;
        this.productId = productId;
        this.cart = cart;
        this.product = product;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}
