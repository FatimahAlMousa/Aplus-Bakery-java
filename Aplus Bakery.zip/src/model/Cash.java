 
package model;
public class Cash {
    private int cashId;
    private Payment payment; // Reference to Payment

    public Cash(int cashId, Payment payment) {
        this.cashId = cashId;
        this.payment = payment;
    }

    public int getCashId() {
        return cashId;
    }

    public void setCashId(int cashId) {
        this.cashId = cashId;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }
}

