package model;

public class Pastry {

    private int pastryId;
    private String pastryType;
    private Product product; // Reference to Product

    public Pastry(int pastryId, String pastryType, Product product) {
        this.pastryId = pastryId;
        this.pastryType = pastryType;
        this.product = product;
    }

    public int getPastryId() {
        return pastryId;
    }

    public void setPastryId(int pastryId) {
        this.pastryId = pastryId;
    }

    public String getPastryType() {
        return pastryType;
    }

    public void setPastryType(String pastryType) {
        this.pastryType = pastryType;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}
